export const TITLE = "Слово, которое есть"
export const HASHTAG = "словокотороеесть"